<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "railway_reservation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the "From", "To", and "Date" from the AJAX request
$from = $_POST['from'];
$to = $_POST['to'];
$date = $_POST['date'];

// Prepare the SQL query to fetch available times for the selected route
$sql = "SELECT departure_time FROM trains WHERE source = ? AND destination = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $from, $to);
$stmt->execute();
$result = $stmt->get_result();

// Initialize the response
$response = "<option value=''>--Select a Time--</option>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Combine the selected date with the available time from the database
        $departure_time = $date . ' ' . $row['departure_time'];
        $formatted_time = date('g:i A', strtotime($departure_time)); // Format the time for display

        // Append the time as an option in the dropdown
        $response .= "<option value='" . $row['departure_time'] . "'>" . $formatted_time . "</option>";
    }
} else {
    // No times available for the selected route and date
    $response .= "<option value=''>No available times</option>";
}

// Return the response to the AJAX request
echo $response;

$stmt->close();
$conn->close();
?>
