<?php
// Start session
session_start();

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'staff')) {
    header("Location: login.php");
    exit();
}


// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "railway_reservation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

// Fetch the user's current details
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Handle form submission to update user details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $role = $_POST['role'];
    $password = $_POST['password'];

    // Hash password if updated
    if (!empty($password)) {
        $password_hashed = password_hash($password, PASSWORD_BCRYPT);
        $update_sql = "UPDATE users SET username = ?, email = ?, phone = ?, role = ?, password = ? WHERE user_id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("sssssi", $username, $email, $phone, $role, $password_hashed, $user_id);
    } else {
        // If password is not updated, leave it unchanged
        $update_sql = "UPDATE users SET username = ?, email = ?, phone = ?, role = ? WHERE user_id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("ssssi", $username, $email, $phone, $role, $user_id);
    }

    if ($stmt->execute()) {
        echo "<p>User details updated successfully!</p>";
    } else {
        echo "<p>Error updating user details.</p>";
    }

    $stmt->close();
    $conn->close();

    // Redirect back to the manage_users page after updating
    header("Location: manage_users.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - Railway Reservation System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Edit User Information</h1>
        </div>
    </header>

    <section class="edit-user">
        <div class="container">
            <form action="edit_user.php?user_id=<?php echo $user_id; ?>" method="POST">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" name="username" id="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="phone">Phone:</label>
                    <input type="text" name="phone" id="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="role">Role:</label>
                    <select name="role" id="role" required>
                        <option value="customer" <?php if ($user['role'] == 'customer') echo 'selected'; ?>>Customer</option>
                        <option value="staff" <?php if ($user['role'] == 'staff') echo 'selected'; ?>>Staff</option>
                        <option value="admin" <?php if ($user['role'] == 'admin') echo 'selected'; ?>>Admin</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="password">Password (leave blank to keep current password):</label>
                    <input type="password" name="password" id="password" placeholder="Enter new password if changing">
                </div>

                <button type="submit" class="cta-btn">Update User</button>
            </form>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 Railway Reservation System. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
