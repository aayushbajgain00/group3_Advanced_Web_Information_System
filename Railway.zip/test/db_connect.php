<?php
// Database connection details
$servername = "localhost";  // Change this if your database is hosted on a different server
$username = "root";         // MySQL username (use the actual username)
$password = "";             // MySQL password (use the actual password)
$dbname = "railway_reservation";  // Name of your database

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// If connected successfully
// echo "Connected successfully"; // Uncomment this for debugging purposes
?>
