<?php
// Start session
session_start();

// Check if admin or staff is logged in
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'staff')) {
    header("Location: login.php");
    exit();
}

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "railway_reservation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch trains
$sql = "SELECT * FROM trains";
$result = $conn->query($sql);

// Handle train addition, update, or deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_train'])) {
        // Handle adding a new train
        $train_name = $_POST['train_name'];
        $source = $_POST['source'];
        $destination = $_POST['destination'];
        $departure_time = $_POST['departure_time'];
        $arrival_time = $_POST['arrival_time'];

        $insert_sql = "INSERT INTO trains (train_name, source, destination, departure_time, arrival_time)
                       VALUES ('$train_name', '$source', '$destination', '$departure_time', '$arrival_time')";
        $conn->query($insert_sql);
    } elseif (isset($_POST['delete_train'])) {
        // Handle deleting a train
        $train_id = $_POST['train_id'];
        $delete_sql = "DELETE FROM trains WHERE train_id='$train_id'";
        $conn->query($delete_sql);
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Trains - Railway Reservation System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Manage Trains</h1>
            <nav>
                <ul>
                    <li><a href="admin_dashboard.php">Dashboard</a></li>
                    <li><a href="manage_reservations.php">Manage Reservations</a></li>
                    <?php if ($_SESSION['role'] == 'admin'): ?>
                        <li><a href="manage_users.php">Manage Users</a></li>
                    <?php endif; ?>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="manage-trains">
        <div class="container">
            <h2>Add New Train</h2>
            <form action="manage_trains.php" method="POST">
                <div class="form-group">
                    <label for="train_name">Train Name:</label>
                    <input type="text" name="train_name" required>
                </div>
                <div class="form-group">
                    <label for="source">Source:</label>
                    <input type="text" name="source" required>
                </div>
                <div class="form-group">
                    <label for="destination">Destination:</label>
                    <input type="text" name="destination" required>
                </div>
                
                <div class="form-group">
                    <label for="departure_time">Departure Time:</label>
                    <input type="datetime-local" name="departure_time" required>
                </div>
                <div class="form-group">
                    <label for="arrival_time">Arrival Time:</label>
                    <input type="datetime-local" name="arrival_time" required>
                </div>
                <button type="submit" name="add_train" class="cta-btn">Add Train</button>
            </form>

            <h2>Current Trains</h2>
            <table>
                <thead>
                    <tr>
                        <th>Train Name</th>
                        <th>Source</th>
                        <th>Destination</th>
                        <th>Departure Time</th>
                        <th>Arrival Time</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['train_name']; ?></td>
                            <td><?php echo $row['source']; ?></td>
                            <td><?php echo $row['destination']; ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($row['departure_time'])); ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($row['arrival_time'])); ?></td>
                            <td>
                                <form action="manage_trains.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="train_id" value="<?php echo $row['train_id']; ?>">
                                    <button type="submit" name="delete_train" class="cta-btn">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 Railway Reservation System. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
