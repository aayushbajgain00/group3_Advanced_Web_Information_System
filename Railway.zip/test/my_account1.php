<?php
// Start session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "railway_reservation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];

// Fetch user details and reservations in a single query
$sql = "SELECT users.username, users.email, users.phone, reservations.reservation_id, reservations.seats_reserved, reservations.status, 
        reservations.reservation_date, trains.train_name, trains.source, trains.destination, trains.departure_time
        FROM users
        JOIN reservations ON users.user_id = reservations.user_id
        JOIN trains ON reservations.train_id = trains.train_id
        WHERE users.user_id = ?";

// Use prepared statement to prevent SQL injection
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if any result is returned
if ($result->num_rows > 0) {
    // Fetch the first result only for user details
    $user = $result->fetch_assoc(); 
} else {
    // Handle case where there are no results (no reservations or invalid user ID)
    echo "No reservations found for this user.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - Railway Reservation System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Railway Reservation System - My Account</h1>
            <nav>
                <ul>
                    <li><a href="my_account1.php">Home</a></li>
                    <li><a href="book_ticket1.php">Book Ticket</a></li>
                    <li><a href="my_account.php">My Account</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="account-section">
        <div class="container">
            <h2>Welcome, <?php echo htmlspecialchars($user['username']); ?>!</h2>

            <!-- Reservations Section -->
            <div class="reservation-history">
                <h3>Your Reservations</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Train Name</th>
                            <th>Source</th>
                            <th>Destination</th>
                            <th>Departure Time</th>
                            <th>Seats Reserved</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Re-run the query to fetch all reservations after extracting user data
                        $stmt->execute();
                        $result = $stmt->get_result();

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                    <td>" . htmlspecialchars($row['train_name']) . "</td>
                                    <td>" . htmlspecialchars($row['source']) . "</td>
                                    <td>" . htmlspecialchars($row['destination']) . "</td>
                                    <td>" . date('F j, Y, g:i a', strtotime($row['departure_time'])) . "</td>
                                    <td>" . htmlspecialchars($row['seats_reserved']) . "</td>
                                    <td>" . ucfirst(htmlspecialchars($row['status'])) . "</td>
                                    
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7'>No reservations found.</td></tr>";
                        }
                        ?>
                    </tbody>

                </table>
            </div>
        </div>
    </section>

    <section class="services">
        <div class="container">
            <div class="service-box">
                <h3>Check Train Schedule</h3>
                <p>View all available trains and their schedules to various destinations.</p>
                <a href="train_schedule1.php">View Schedules</a>
            </div>
            <div class="service-box">
                <h3>Book a Ticket</h3>
                <p>Select your preferred train and book your tickets online in just a few clicks.</p>
                <a href="book_ticket1.php">Book Now</a>
            </div>
            <div class="service-box">
                <h3>Manage Your Account</h3>
                <p>Login to view your booking history, manage your profile, and make reservations.</p>
                <a href="my_account.php">Manage Account</a>
            </div>
        </div>
    </section>


    <footer>
        <div class="container">
            <p>&copy; 2024 Railway Reservation System. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
