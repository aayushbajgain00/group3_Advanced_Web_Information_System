<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "railway_reservation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle registration form submission
$success_msg = '';
$error_msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Check if email already exists
    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows == 0) {
        // Insert new user into database
        $insert_sql = "INSERT INTO users (username, email, phone, password, role) VALUES ('$username', '$email', '$phone', '$password', 'customer')";

        if ($conn->query($insert_sql) === TRUE) {
            $success_msg = "Registration successful! You can now login.";
        } else {
            $error_msg = "Error: " . $conn->error;
        }
    } else {
        $error_msg = "Email is already registered!";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration - Railway Reservation System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Railway Reservation System</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="train_schedule.php">Trains</a></li>
                    <li><a href="book_ticket.php">Book Ticket</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    
                </ul>
            </nav>
        </div>
    </header>

    <section class="register-form">
        <div class="container">
            <h2>Create an Account</h2>

            <?php if ($success_msg): ?>
                <p class="success-message"><?php echo $success_msg; ?></p>
            <?php endif; ?>

            <?php if ($error_msg): ?>
                <p class="error-message"><?php echo $error_msg; ?></p>
            <?php endif; ?>

            <form action="register.php" method="POST">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" name="username" id="username" required>
                </div>

                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" name="email" id="email" required>
                </div>

                <div class="form-group">
                    <label for="phone">Phone:</label>
                    <input type="text" name="phone" id="phone" required>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" name="password" id="password" required>
                </div>

                <button type="submit" class="cta-btn">Register</button>
            </form>

            <p>Already have an account? <a href="login.php">Login here</a>.</p>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 Railway Reservation System. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
