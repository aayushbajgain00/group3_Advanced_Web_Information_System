<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$reservation_id = intval($_GET['reservation_id']);
$user_id = $_SESSION['user_id'];

// Connect to the database
$conn = new mysqli("localhost", "root", "", "railway_reservation");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Update reservation status to "cancelled"
$stmt = $conn->prepare("UPDATE reservations SET status = 'cancelled' WHERE reservation_id = ? AND user_id = ?");
$stmt->bind_param("ii", $reservation_id, $user_id);

if ($stmt->execute()) {
    echo "<p>Reservation cancelled successfully!</p>";
} else {
    echo "<p>Error canceling reservation.</p>";
}

$stmt->close();
$conn->close();

header("Location: my_account.php");
exit();
?>
