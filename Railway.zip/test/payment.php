<?php
// Start session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "railway_reservation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch reservation details from session
$amount = isset($_SESSION['amount']) ? $_SESSION['amount'] : 0; // Amount after booking
$reservation_id = isset($_SESSION['reservation_id']) ? $_SESSION['reservation_id'] : 0; // Reservation ID

// Simulate payment success on form submission
$success_msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Dummy process: Simulate payment success
    $payment_status = 'completed';
    
    // Insert payment into database
    $sql = "INSERT INTO payments (reservation_id, amount, payment_status) 
            VALUES ('$reservation_id', '$amount', '$payment_status')";
    if ($conn->query($sql) === TRUE) {
        // Update the reservation status
        $update_sql = "UPDATE reservations SET status='booked' WHERE reservation_id='$reservation_id'";
        $conn->query($update_sql);

        // Confirm payment
        $success_msg = "Payment successful! Your reservation is now confirmed.";
    } else {
        $success_msg = "Error processing the payment: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - Railway Reservation System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Railway Reservation System - Payment</h1>
            <nav>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="train_schedule.php">Trains</a></li>
                    <li><a href="my_account.php">My Account</a></li>
                    <li><a href="admin_login.php">Admin Login</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="payment">
        <div class="container">
            <h2>Make a Payment</h2>
            <p>Total Amount: $<?php echo $amount; ?></p>

            <?php if ($success_msg): ?>
                <p class="success-message"><?php echo $success_msg; ?></p>
            <?php else: ?>
                <form action="payment.php" method="POST">
                    <div class="form-group">
                        <label for="card_number">Card Number (Dummy):</label>
                        <input type="text" name="card_number" id="card_number" placeholder="1234 1234 1234 1234" required>
                    </div>

                    <div class="form-group">
                        <label for="expiry_date">Expiry Date (Dummy):</label>
                        <input type="text" name="expiry_date" id="expiry_date" placeholder="MM/YY" required>
                    </div>

                    <div class="form-group">
                        <label for="cvv">CVV (Dummy):</label>
                        <input type="text" name="cvv" id="cvv" required>
                    </div>

                    <button type="submit" class="cta-btn">Pay Now</button>
                </form>
            <?php endif; ?>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 Railway Reservation System. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
