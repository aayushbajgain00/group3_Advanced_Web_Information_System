-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 10, 2024 at 07:34 AM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `railway_reservation`
--

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
CREATE TABLE IF NOT EXISTS `payments` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `reservation_id` int DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `payment_status` enum('completed','failed') DEFAULT 'completed',
  PRIMARY KEY (`payment_id`),
  KEY `reservation_id` (`reservation_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `reservation_id`, `amount`, `payment_date`, `payment_status`) VALUES
(1, 1, 50.00, '2024-10-01 18:47:05', 'completed'),
(2, 2, 25.00, '2024-10-01 18:47:05', 'completed'),
(3, 0, 0.00, '2024-10-01 19:35:07', 'completed'),
(4, 0, 0.00, '2024-10-01 19:52:47', 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
CREATE TABLE IF NOT EXISTS `reservations` (
  `reservation_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `train_id` int DEFAULT NULL,
  `seats_reserved` int DEFAULT NULL,
  `status` enum('booked','cancelled') DEFAULT NULL,
  `reservation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `travel_date` date DEFAULT NULL,
  PRIMARY KEY (`reservation_id`),
  KEY `user_id` (`user_id`),
  KEY `train_id` (`train_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`reservation_id`, `user_id`, `train_id`, `seats_reserved`, `status`, `reservation_date`, `travel_date`) VALUES
(1, 5, 0, 0, 'booked', '2024-10-01 10:24:07', '2024-01-01'),
(2, 5, 1, 4, 'booked', '2024-10-01 10:31:43', '2024-01-01'),
(3, 4, 2, 2, 'booked', '2024-10-01 10:32:36', '2024-01-01'),
(4, 6, 2, 2, 'booked', '2024-10-01 10:34:00', '2024-01-01'),
(5, 4, 2, 9, 'cancelled', '2024-10-01 10:40:54', '2024-01-01'),
(6, 4, 1, 3, 'cancelled', '2024-10-01 10:48:54', '2024-01-01'),
(7, 6, 1, 1, 'booked', '2024-10-01 10:49:29', '2024-01-01'),
(8, 4, 1, 4, 'booked', '2024-10-01 13:07:33', '2024-01-01'),
(9, 4, 11, 2, 'booked', '2024-10-08 08:24:03', '2024-01-01'),
(10, 7, 12, 1, 'booked', '2024-10-09 05:46:31', '2024-01-01'),
(11, 3, 4, 3, 'booked', '2024-10-09 09:45:07', '2024-01-01'),
(12, 3, 12, 3, 'booked', '2024-10-09 09:46:20', '2024-01-01'),
(13, 8, 12, 5, 'booked', '2024-10-09 09:48:16', '2024-01-01'),
(14, 3, 14, 4, 'booked', '2024-10-09 10:02:55', '2024-01-01'),
(15, 3, 10, 4, 'booked', '2024-10-09 10:40:37', '2024-01-01'),
(16, 4, 2, 5, 'booked', '2024-10-09 10:46:45', '0000-00-00'),
(17, 4, 17, 90, 'booked', '2024-10-09 11:13:15', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stations`
--

DROP TABLE IF EXISTS `stations`;
CREATE TABLE IF NOT EXISTS `stations` (
  `station_id` int NOT NULL AUTO_INCREMENT,
  `station_name` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`station_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `stations`
--

INSERT INTO `stations` (`station_id`, `station_name`, `location`) VALUES
(1, 'Central Station', 'Sydney'),
(2, 'Flinders Street Station', 'Melbourne'),
(3, 'Brisbane Central', 'Brisbane');

-- --------------------------------------------------------

--
-- Table structure for table `trains`
--

DROP TABLE IF EXISTS `trains`;
CREATE TABLE IF NOT EXISTS `trains` (
  `train_id` int NOT NULL AUTO_INCREMENT,
  `train_name` varchar(255) NOT NULL,
  `source` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `departure_time` time NOT NULL,
  `arrival_time` time NOT NULL,
  PRIMARY KEY (`train_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `trains`
--

INSERT INTO `trains` (`train_id`, `train_name`, `source`, `destination`, `departure_time`, `arrival_time`) VALUES
(1, 'Sydney Express', 'Sydney', 'Melbourne', '08:00:00', '14:00:00'),
(2, 'Melbourne Express', 'Melbourne', 'Sydney', '15:00:00', '21:00:00'),
(3, 'Coastal Runner', 'Sydney', 'Brisbane', '12:00:00', '20:00:00'),
(4, 'Brisbane Coastal Runner', 'Brisbane', 'Sydney', '10:00:00', '18:00:00'),
(5, 'Morning Coastal Express', 'Sydney', 'Newcastle', '07:00:00', '09:00:00'),
(6, 'Evening Coastal Express', 'Sydney', 'Newcastle', '18:00:00', '20:00:00'),
(7, 'Morning Return Coastal', 'Newcastle', 'Sydney', '10:00:00', '12:00:00'),
(8, 'Evening Return Coastal', 'Newcastle', 'Sydney', '21:00:00', '23:00:00'),
(9, 'Pacific Explorer', 'Sydney', 'Perth', '06:00:00', '22:00:00'),
(10, 'Western Explorer', 'Perth', 'Sydney', '06:00:00', '22:00:00'),
(11, 'Southern Express', 'Melbourne', 'Adelaide', '09:00:00', '13:00:00'),
(12, 'Adelaide Return Express', 'Adelaide', 'Melbourne', '15:00:00', '19:00:00'),
(13, 'Northern Pioneer', 'Brisbane', 'Cairns', '07:00:00', '17:00:00'),
(14, 'Cairns Pioneer Return', 'Cairns', 'Brisbane', '07:00:00', '17:00:00'),
(15, 'Mountain Rider', 'Sydney', 'Blue Mountains', '08:00:00', '11:00:00'),
(16, 'Mountain Return', 'Blue Mountains', 'Sydney', '12:00:00', '15:00:00'),
(17, 'Capital Express', 'Canberra', 'Sydney', '09:00:00', '13:00:00'),
(18, 'Sydney Capital Return', 'Sydney', 'Canberra', '14:00:00', '18:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `train_routes`
--

DROP TABLE IF EXISTS `train_routes`;
CREATE TABLE IF NOT EXISTS `train_routes` (
  `route_id` int NOT NULL AUTO_INCREMENT,
  `train_id` int DEFAULT NULL,
  `station_id` int DEFAULT NULL,
  `stop_number` int DEFAULT NULL,
  `arrival_time` datetime DEFAULT NULL,
  `departure_time` datetime DEFAULT NULL,
  PRIMARY KEY (`route_id`),
  KEY `train_id` (`train_id`),
  KEY `station_id` (`station_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `train_routes`
--

INSERT INTO `train_routes` (`route_id`, `train_id`, `station_id`, `stop_number`, `arrival_time`, `departure_time`) VALUES
(1, 1, 1, 1, '2024-10-01 09:00:00', '2024-10-01 09:10:00'),
(2, 1, 2, 2, '2024-10-01 14:50:00', '2024-10-01 15:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `role` enum('customer','staff','admin') DEFAULT 'customer',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`, `phone`, `role`, `created_at`) VALUES
(1, 'john_doe', 'hashedpassword1', 'john@example.com', '1234567890', 'customer', '2024-10-01 18:47:05'),
(2, 'staff_user', '$2y$10$kxSnIPEMDYjT6NVGl65DEuCgzTr.SPBU4BHVkO39ooq8tC8BW/xuq', 'staff@example.com', '0987654321', 'staff', '2024-10-01 18:47:05'),
(3, 'admin_user', '$2y$10$ebl/hPeEeA.DkzxrmELVTe0WqB3bs13xILabTQyxq5xqJVZerWMMa', 'admin@example.com', '1122334455', 'admin', '2024-10-01 18:47:05'),
(4, 'kiran', '$2y$10$CCfBQcLYHu474.MNqE1z4eItbEjMYt43WLw7iOMaw5EKxkK2GtxEC', 'kbc@kbc.com', '0987654321', 'customer', '2024-10-01 19:05:58'),
(5, 'Aayush', '', 'abc@abc.com', '0987654321', 'customer', '2024-10-01 20:24:07'),
(6, 'Ashok Pandu', '', 'asad@sdfv.com', '0987654321', '', '2024-10-01 20:34:00'),
(7, 'Diwas KD', '', 'kd@abc.com', '25737', 'customer', '2024-10-09 16:46:31'),
(8, 'Sairash Pathak', '', 'sp@abc.com', '673782382', 'customer', '2024-10-09 20:48:16');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
