<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Railway Reservation System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Railway Reservation System</h1>
            <nav>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="train_schedule.php">Trains</a></li>
                    <li><a href="book_ticket.php">Book Ticket</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="login.php">LogIn</a></li>
                    
                </ul>
            </nav>
        </div>
    </header>

    <section class="hero">
        <div class="container">
            <h2>Book Your Train Tickets Easily and Quickly</h2>
            <p>Explore available trains, book tickets, and manage your reservations with ease!</p>
            <a href="register.php" class="cta-btn">Get Started</a>
        </div>
    </section>

    <section class="services">
        <div class="container">
            <div class="service-box">
                <h3>Check Train Schedule</h3>
                <p>View all available trains and their schedules to various destinations.</p>
                <a href="train_schedule.php">View Schedules</a>
            </div>
            <div class="service-box">
                <h3>Book a Ticket</h3>
                <p>Select your preferred train and book your tickets online in just a few clicks.</p>
                <a href="book_ticket.php">Book Now</a>
            </div>
            <div class="service-box">
                <h3>Manage Your Account</h3>
                <p>Login to view your booking history, manage your profile, and make reservations.</p>
                <a href="login.php">Manage Account</a>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 Railway Reservation System. All rights reserved.</p>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>
