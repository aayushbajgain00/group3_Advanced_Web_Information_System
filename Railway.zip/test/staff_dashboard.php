<?php
// Start session
session_start();

// Check if staff or staff is logged in
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'staff' && $_SESSION['role'] != 'staff')) {
    header("Location: staff_login.php");
    exit();
}

// Display different sections based on role
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard - Railway Reservation System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Welcome to the Staff Dashboard</h1>
            <nav>
                <ul>
                    <li><a href="manage_trains1.php">Manage Trains</a></li>
                    <li><a href="manage_reservations1.php">Manage Reservations</a></li>
                    <?php if ($_SESSION['role'] == 'staff'): ?>
                        <li><a href="manage_users1.php">Manage Users</a></li>
                    <?php endif; ?>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="dashboard">
        <div class="container">
            <h2>Dashboard</h2>
            <p>Welcome, <?php echo $_SESSION['username']; ?>! You are logged in as <?php echo $_SESSION['role']; ?>.</p>

            <div class="admin-options">
                <a href="manage_trains1.php" class="cta-btn">Manage Trains</a>
                <a href="manage_reservations1.php" class="cta-btn">Manage Reservations</a>
                <?php if ($_SESSION['role'] == 'staff'): ?>
                    <a href="manage_users1.php" class="cta-btn">Manage Users</a>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 Railway Reservation System. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
