<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "railway_reservation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the selected "From" station from the AJAX request
$from = $_POST['from'];

// Query to get all distinct destinations from the selected "From" station
$sql = "SELECT DISTINCT destination FROM trains WHERE source = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $from);
$stmt->execute();
$result = $stmt->get_result();

// Initialize the response with a default option
$response = "<option value=''>--Select a Destination Station--</option>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $response .= "<option value='" . $row['destination'] . "'>" . $row['destination'] . "</option>";
    }
} else {
    // No destinations available for the selected "From"
    $response .= "<option value=''>No available destinations</option>";
}

// Return the response to the AJAX request
echo $response;

$stmt->close();
$conn->close();
?>
