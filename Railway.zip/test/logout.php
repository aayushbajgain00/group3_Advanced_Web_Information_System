<?php
// Start the session
session_start();

// Destroy all session variables
$_SESSION = array();

// If session cookies are used, delete the session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Finally, destroy the session
session_destroy();

// Redirect the user to the login page (or home page)
header("Location: index.php"); // Change to "index.html" if you want to redirect to the homepage
exit();
