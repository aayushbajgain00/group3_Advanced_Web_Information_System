// Basic script to add interactivity (if needed)
// You can expand this as the site grows

document.addEventListener("DOMContentLoaded", function() {
    const ctaButton = document.querySelector('.cta-btn');
    
    ctaButton.addEventListener('click', function() {
        window.location.href = 'book.html'; // This would navigate to the booking page
    });
});
