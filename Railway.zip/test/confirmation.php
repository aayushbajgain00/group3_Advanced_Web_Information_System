<?php
session_start();

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "railway_reservation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data from POST request
$from = $_POST['from'];
$to = $_POST['to'];
$date = $_POST['date'];
$time = $_POST['time'];
$seats_reserved = $_POST['seats_reserved'];
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;

// If the user is not logged in, get user details from form
if (!$user_id) {
    $username = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    // Check if the user already exists in the users table
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Existing user found, use their user_id
        $user = $result->fetch_assoc();
        $user_id = $user['user_id'];
    } else {
        // New user, insert into users table
        $stmt = $conn->prepare("INSERT INTO users (username, email, phone) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $phone);
        $stmt->execute();
        $user_id = $conn->insert_id; // Get the new user's ID
    }
}

// Format the departure datetime by combining date and time fields
$departure_datetime = $date . ' ' . $time;

// Insert the reservation into the reservations table
$stmt = $conn->prepare("INSERT INTO reservations (user_id, train_id, seats_reserved, status) 
                        SELECT ?, train_id, ?, 'booked' 
                        FROM trains 
                        WHERE source = ? AND destination = ? AND departure_time = ?");
$stmt->bind_param("iisss", $user_id, $seats_reserved, $from, $to, $departure_datetime);

if ($stmt->execute()) {
    echo "<p>Reservation successfully made!</p>";
    // Optionally, you can redirect to a success page or display more information
    echo "<p>Your train is departing from $from to $to at $departure_datetime.</p>";
} else {
    echo "<p>Failed to make reservation. Please try again.</p>";
}

$stmt->close();
$conn->close();
?>
