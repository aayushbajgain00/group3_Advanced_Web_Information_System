<?php
// Start session
session_start();

// Check if admin or staff is logged in
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'staff')) {
    header("Location: login.php");
    exit();
}

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "railway_reservation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch reservations
$sql = "SELECT r.reservation_id, r.seats_reserved, r.status, r.reservation_date, t.train_name, u.username 
        FROM reservations r 
        JOIN trains t ON r.train_id = t.train_id
        JOIN users u ON r.user_id = u.user_id";
$result = $conn->query($sql);

// Handle reservation cancellation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_reservation'])) {
    $reservation_id = $_POST['reservation_id'];
    $cancel_sql = "UPDATE reservations SET status='cancelled' WHERE reservation_id='$reservation_id'";
    $conn->query($cancel_sql);
    header("Location: manage_reservations.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Reservations - Railway Reservation System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Manage Reservations</h1>
            <nav>
                <ul>
                    <li><a href="admin_dashboard.php">Dashboard</a></li>
                    <li><a href="manage_trains.php">Manage Trains</a></li>
                    <?php if ($_SESSION['role'] == 'admin'): ?>
                        <li><a href="manage_users.php">Manage Users</a></li>
                    <?php endif; ?>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="manage-reservations">
        <div class="container">
            <h2>Reservation List</h2>
            <table>
                <thead>
                    <tr>
                        <th>Reservation ID</th>
                        <th>Train Name</th>
                        <th>Username</th>
                        <th>Seats Reserved</th>
                        <th>Status</th>
                        <th>Reservation Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['reservation_id']; ?></td>
                                <td><?php echo $row['train_name']; ?></td>
                                <td><?php echo $row['username']; ?></td>
                                <td><?php echo $row['seats_reserved']; ?></td>
                                <td><?php echo $row['status']; ?></td>
                                <td><?php echo date('F j, Y, g:i a', strtotime($row['reservation_date'])); ?></td>
                                <td>
                                <td>
                                    <?php if ($row['status'] != 'cancelled'): ?>
                                        <form method="POST" action="manage_reservations.php">
                                            <input type="hidden" name="reservation_id" value="<?php echo $row['reservation_id']; ?>">
                                            <button type="submit" name="cancel_reservation" class="cancel-btn">Cancel</button>
                                        </form>
                                    <?php else: ?>
                                        <span>Cancelled</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7">No reservations found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 Railway Reservation System. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
