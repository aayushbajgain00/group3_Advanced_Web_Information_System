<?php
// Start session
session_start();

// Check if the user is logged in
$is_logged_in = isset($_SESSION['user_id']);
$user_id = $is_logged_in ? $_SESSION['user_id'] : 0;

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "railway_reservation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch distinct cities/stations for "From" and "To" dropdowns
$from_sql = "SELECT DISTINCT source FROM trains";
$from_result = $conn->query($from_sql);

$to_sql = "SELECT DISTINCT destination FROM trains";
$to_result = $conn->query($to_sql);

// Get today's date in YYYY-MM-DD format for setting the minimum date
$today = date('Y-m-d');

// Pre-fill user details if logged in
if ($is_logged_in) {
    $stmt = $conn->prepare("SELECT username, email, phone FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $user_result = $stmt->get_result()->fetch_assoc();
    $username = $user_result['username'];
    $email = $user_result['email'];
    $phone = $user_result['phone'];
} else {
    $username = $email = $phone = '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $train_id = $_POST['train_id'];
    $seats_reserved = $_POST['seats_reserved'];
    $total_price = $seats_reserved * 25; // Assume each seat costs $25

    if (!$is_logged_in) {
        // Get personal information from the form (only for non-logged-in users)
        $username = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];

        // Check if the email already exists
        $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $user_id = $user['user_id'];
        } else {
            $stmt = $conn->prepare("INSERT INTO users (username, email, phone) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $email, $phone);
            $stmt->execute();
            $user_id = $conn->insert_id;
        }
    }

    // Insert the reservation
    $stmt = $conn->prepare("INSERT INTO reservations (user_id, train_id, seats_reserved, status) VALUES (?, ?, ?, ?)");
    $status = 'booked';
    $stmt->bind_param("iiis", $user_id, $train_id, $seats_reserved, $status);
    if ($stmt->execute()) {
        echo "<p>Reservation successfully made!</p><p>Total Price: $$total_price</p>";
    } else {
        echo "<p>Failed to make reservation.</p>";
    }

    $stmt->close();
    $conn->close();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Ticket - Railway Reservation System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Railway Reservation System</h1>
            <nav>
                <ul>
                    <li><a href="my_account.php">Home</a></li>
                    <li><a href="#">Book Ticket</a></li>
                    <li><a href="my_account.php">My Account</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="book-ticket">
        <div class="container">
            <h2>Book Your Train Ticket</h2>
            <form action="confirmation.php" method="POST">

                
                <!-- From Dropdown -->
                <div class="form-group">
                    <label for="from">From:</label>
                    <select name="from" id="from" required>
                        <option value="">--Select a Departure Station--</option>
                        <?php while ($row = $from_result->fetch_assoc()): ?>
                            <option value="<?php echo $row['source']; ?>"><?php echo $row['source']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <!-- To Dropdown (Dynamic based on selected From) -->
                <div class="form-group">
                    <label for="to">To:</label>
                    <select name="to" id="to" required>
                        <option value="">--Select a Destination Station--</option>
                    </select>
                </div>


                <!-- Date Picker -->
                <div class="form-group">
                    <label for="date">Date:</label>
                    <input type="date" name="date" id="date" min="<?php echo $today; ?>" required>
                </div>

                <!-- Time Dropdown (to be populated based on selected From/To and Date) -->
                <div class="form-group">
                    <label for="time">Time:</label>
                    <select name="time" id="time" required>
                        <option value="">--Select a Time--</option>
                        
                        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                        <script>
                        $(document).ready(function() {
                            // When "From", "To", or "Date" fields are changed, fetch available times
                            $('#from, #to, #date').on('change', function() {
                                let from = $('#from').val();
                                let to = $('#to').val();
                                let date = $('#date').val();

                                // Only fetch times if all fields are selected
                                if (from && to && date) {
                                    $.ajax({
                                        url: 'fetch_times.php', // This script will fetch the available times
                                        type: 'POST',
                                        data: {
                                            from: from,
                                            to: to,
                                            date: date
                                        },
                                        success: function(response) {
                                            $('#time').html(response); // Populate the "Time" dropdown with the fetched options
                                        }
                                    });
                                }
                            });
                        });
                        </script>
                    </select>
                </div>

                <!-- Number of Seats -->
                <div class="form-group">
                    <label for="seats_reserved">Number of Seats:</label>
                    <input type="number" name="seats_reserved" id="seats_reserved" required min="1">
                </div>

                <!-- User Details (for non-logged-in users) -->
                <?php if (!$is_logged_in): ?>
                    <div class="form-group">
                        <label for="name">Full Name:</label>
                        <input type="text" name="name" id="name" required value="<?php echo $username; ?>">
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address:</label>
                        <input type="email" name="email" id="email" required value="<?php echo $email; ?>">
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone Number:</label>
                        <input type="text" name="phone" id="phone" required value="<?php echo $phone; ?>">
                    </div>
                <?php endif; ?>

                <button type="submit" class="cta-btn">Submit Reservation</button>
            </form>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 Railway Reservation System. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(document).ready(function() {
        // When "From" field is changed, fetch available destinations
        $('#from').on('change', function() {
            let from = $('#from').val();

            if (from) {
                $.ajax({
                    url: 'fetch_destinations.php', // This script will fetch the available destinations
                    type: 'POST',
                    data: { from: from },
                    success: function(response) {
                        $('#to').html(response); // Populate the "To" dropdown with the fetched options
                    }
                });
            } else {
                $('#to').html('<option value="">--Select a Destination Station--</option>'); // Reset if no "From" selected
            }
        });
    });
    </script>

</body>
</html>