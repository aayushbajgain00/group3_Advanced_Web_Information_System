<?php
// Start session
session_start();

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "railway_reservation";

$conn = new mysqli($servername, $username, $password, $dbname);
$error_msg = '';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle login submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_input = $_POST['email'];  // This can now be either email or username
    $password = $_POST['password'];

    // Fetch user details from database based on the provided email
    $sql = "SELECT * FROM users WHERE email='$user_input'";
    $result = $conn->query($sql);

// Handle login submission

if ($result->num_rows == 1) {
    $user = $result->fetch_assoc();
    
    // Verify password (assuming password is hashed)
    if (password_verify($password, $user['password'])) {
        // Create session
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role']; // Store role in session
        
        // Redirect based on the user's role
        if ($user['role'] == 'admin') {
            header("Location: admin_dashboard.php"); // Admin Dashboard
        } elseif ($user['role'] == 'staff') {
            header("Location: staff_dashboard.php"); // Staff Dashboard
        } else {
            header("Location: my_account1.php"); // Customer/User Dashboard
        }
        exit();
    } else {
        $error_msg = "Invalid password!";
    }
} else {
    $error_msg = "No user found with this email or username!";
}
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login - Railway Reservation System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Railway Reservation System</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="train_schedule.php">Trains</a></li>
                    <li><a href="book_ticket.php">Book Ticket</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="login-form">
        <div class="container">
            <h2>Login to Your Account</h2>
            <?php if ($error_msg): ?>
                <p class="error-message"><?php echo $error_msg; ?></p>
            <?php endif; ?>

            <form action="login.php" method="POST">
                <div class="form-group">
                    <label for="email">Username/Email:</label>
                    <input type="text" name="email" id="email" required>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" name="password" id="password" required>
                </div>

                <button type="submit" class="cta-btn">Login</button>
            </form>

            <p>Don't have an account? <a href="register.php">Register here</a>.</p>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 Railway Reservation System. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
