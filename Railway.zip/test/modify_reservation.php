<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$reservation_id = intval($_GET['reservation_id']);
$user_id = $_SESSION['user_id'];

// Connect to the database
$conn = new mysqli("localhost", "root", "", "railway_reservation");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the current reservation details
$stmt = $conn->prepare("SELECT * FROM reservations WHERE reservation_id = ? AND user_id = ?");
$stmt->bind_param("ii", $reservation_id, $user_id);
$stmt->execute();
$reservation = $stmt->get_result()->fetch_assoc();

// Fetch trains for the dropdown
$train_result = $conn->query("SELECT train_id, train_name, source, destination, departure_time FROM trains");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $train_id = $_POST['train_id'];
    $seats_reserved = $_POST['seats_reserved'];

    // Update the reservation details
    $stmt = $conn->prepare("UPDATE reservations SET train_id = ?, seats_reserved = ? WHERE reservation_id = ? AND user_id = ?");
    $stmt->bind_param("iiii", $train_id, $seats_reserved, $reservation_id, $user_id);

    if ($stmt->execute()) {
        echo "<p>Reservation updated successfully!</p>";
    } else {
        echo "<p>Error updating reservation.</p>";
    }

    $stmt->close();
    $conn->close();

    header("Location: my_account.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modify Reservation - Railway Reservation System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Modify Reservation</h1>
        </div>
    </header>

    <section class="modify-reservation">
        <div class="container">
            <form action="modify_reservation.php?reservation_id=<?php echo $reservation_id; ?>" method="POST">
                <div class="form-group">
                    <label for="train_id">Select New Train:</label>
                    <select name="train_id" id="train_id" required>
                        <?php while ($row = $train_result->fetch_assoc()): ?>
                            <option value="<?php echo $row['train_id']; ?>" <?php if ($row['train_id'] == $reservation['train_id']) echo 'selected'; ?>>
                                <?php echo $row['train_name']; ?> (From <?php echo $row['source']; ?> to <?php echo $row['destination']; ?> - <?php echo date('g:i A', strtotime($row['departure_time'])); ?>)
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="seats_reserved">Update Number of Seats:</label>
                    <input type="number" name="seats_reserved" id="seats_reserved" value="<?php echo $reservation['seats_reserved']; ?>" required min="1">
                </div>

                <button type="submit" class="cta-btn">Update Reservation</button>
            </form>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 Railway Reservation System. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
