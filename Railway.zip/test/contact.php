<?php
session_start();

// Define variables and set to empty values
$name = $email = $message = "";
$nameErr = $emailErr = $messageErr = $successMsg = "";

// Form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $valid = true;

    // Validate name
    if (empty($_POST["name"])) {
        $nameErr = "Name is required";
        $valid = false;
    } else {
        $name = clean_input($_POST["name"]);
    }

    // Validate email
    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
        $valid = false;
    } elseif (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email format";
        $valid = false;
    } else {
        $email = clean_input($_POST["email"]);
    }

    // Validate message
    if (empty($_POST["message"])) {
        $messageErr = "Message is required";
        $valid = false;
    } else {
        $message = clean_input($_POST["message"]);
    }

    // If all inputs are valid, show success message (In real cases, save or email the data)
    if ($valid) {
        $successMsg = "Thank you for contacting us, $name! We will get back to you soon.";
        // You can send the message via email here or save it in the database
        // mail($to, $subject, $message, $headers);  <-- Example for sending email
    }
}

// Function to clean input data
function clean_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Railway Reservation System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Contact Us</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="train_schedule.php">Trains</a></li>
                    <li><a href="book_ticket.php">Book Ticket</a></li>
                    <li><a href="my_account">My Account</a></li>
                    <li><a href="#">Contact Us</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="contact-section">
        <div class="container">
            <h2>Get in Touch</h2>
            
            <?php if ($successMsg): ?>
                <p class="success-message"><?php echo $successMsg; ?></p>
            <?php endif; ?>

            <form action="contact.php" method="POST">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" name="name" id="name" value="<?php echo $name; ?>" required>
                    <span class="error"><?php echo $nameErr; ?></span>
                </div>

                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" name="email" id="email" value="<?php echo $email; ?>" required>
                    <span class="error"><?php echo $emailErr; ?></span>
                </div>

                <div class="form-group">
                    <label for="message">Message:</label>
                    <textarea name="message" id="message" rows="5" required><?php echo $message; ?></textarea>
                    <span class="error"><?php echo $messageErr; ?></span>
                </div>

                <button type="submit" class="cta-btn">Send Message</button>
            </form>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 Railway Reservation System. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
