<?php
// train_schedule.php
// Connect to the database
$servername = "localhost"; // Replace with your database server details
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "railway_reservation"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Get today's date in 'Y-m-d H:i:s' format
$today = date('Y-m-d H:i:s');

// Fetch train schedules where the departure time is in the future (today or later)
$sql = "SELECT train_name, source, destination, departure_time, arrival_time 
        FROM trains 
        WHERE departure_time >= '$today' 
        ORDER BY departure_time ASC";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Train Schedule - Railway Reservation System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Railway Reservation System</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="#">Trains</a></li>
                    <li><a href="book_ticket.php">Book Ticket</a></li>
                    <li><a href="my_account.php">My Account</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="train-schedule">
        <div class="container">
            <h2>Available Train Schedules</h2>
            <table>
                <thead>
                    <tr>
                        <th>Train Name</th>
                        <th>Source</th>
                        <th>Destination</th>
                        <th>Departure Time</th>
                        <th>Arrival Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Check if there are results and loop through the results to display train details
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td>" . $row["train_name"] . "</td>
                                <td>" . $row["source"] . "</td>
                                <td>" . $row["destination"] . "</td>
                                <td>" . date("F j, Y, g:i a", strtotime($row["departure_time"])) . "</td>
                                <td>" . date("F j, Y, g:i a", strtotime($row["arrival_time"])) . "</td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No trains available</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 Railway Reservation System. All rights reserved.</p>
        </div>
    </footer>

    <?php
    // Close the database connection
    $conn->close();
    ?>
</body>
</html>
